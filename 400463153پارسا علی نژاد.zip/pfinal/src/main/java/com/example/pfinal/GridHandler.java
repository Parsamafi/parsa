package com.example.pfinal;

import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class GridHandler extends GridBase {
    Color background1= Color.WHITE;
    Color background2=Color.GRAY;

    public GridHandler(double planeWidth, double planeHeight, int gridSize, AnchorPane anchorPane) {
        super(planeWidth, planeHeight, gridSize, anchorPane);
    }
    public void updateGrid(){
        for (int i = 0; i <getTilesAmount() ; i++) {
            int x=(i%getTilesAcross());
            int y=(i/getTilesAcross());
            Rectangle rectangle=new Rectangle(x*getGridSize(),y*getGridSize(),getGridSize(),getGridSize());
            if((x+y)%2==0){
                rectangle.setFill(background1);
            } else {
                rectangle.setFill(background2);
            }
            getAnchorPane().getChildren().add(rectangle);
            {

            }
        }
    }

}
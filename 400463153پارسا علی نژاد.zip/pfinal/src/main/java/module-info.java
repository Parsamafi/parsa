module com.example.pfinal {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.pfinal to javafx.fxml;
    exports com.example.pfinal;
}
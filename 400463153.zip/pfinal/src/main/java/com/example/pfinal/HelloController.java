package com.example.pfinal;

import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ColorPicker;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.regex.Pattern;

public class HelloController implements Initializable {
    /*private BooleanProperty wpressed=new SimpleBooleanProperty();
    private BooleanProperty spressed=new SimpleBooleanProperty();
    private BooleanProperty apressed=new SimpleBooleanProperty();
    private BooleanProperty dpressed=new SimpleBooleanProperty();
    private BooleanBinding keypressed = wpressed.or(apressed).or(spressed).or(dpressed);
    private int movementVariable=2;*/
    /*AnimationTimer timer=new AnimationTimer() {
        @Override
        public void handle(long timestamp) {
            if (wpressed.get()) {
                square.setLayoutY(square.getLayoutY()-movementVariable);
            }
            if (spressed.get()){
                square.setLayoutY(square.getLayoutY()+movementVariable);
            }
            if (apressed.get()) {
                square.setLayoutX(square.getLayoutX()-movementVariable);
            }
            if (dpressed.get()){
                square.setLayoutX(square.getLayoutX()+movementVariable);
            }
        }
    };*/


    @FXML
    private AnchorPane scene2;
    private GridHandler backggetroundGridHandler;
    private int gridsize=50;


    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private ColorPicker mycolorpicker1;

    @FXML
    private ColorPicker mycolorpicker2;

    @FXML
    private Rectangle myrectangle1;

    @FXML
    private Rectangle myrectangle2;

    @FXML
    private Button start;

    @FXML
    void changecolor1(ActionEvent event) {
        Color mycolor= mycolorpicker1.getValue();
        myrectangle1.setFill(mycolor);
    }

    @FXML
    void changecolor2(ActionEvent event) {
        Color mycolor= mycolorpicker2.getValue();
        myrectangle2.setFill(mycolor);
    }

    @FXML
    void switchtoScene2(ActionEvent event) throws IOException {
        Parent root= FXMLLoader.load(getClass().getResource("Scene2.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        stage.setScene(scene);
        stage.show();

    }





    /*FadeTransition fadeTransition=new FadeTransition(Duration.seconds(1),rectangle);
        fadeTransition.setFromValue(1.0);
        fadeTransition.setToValue(0);
        fadeTransition.play();*/









    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        backggetroundGridHandler =new GridHandler(scene2.getPrefWidth(),scene2.getPrefHeight(),gridsize,scene2);
        backggetroundGridHandler.updateGrid();
 /*       movementSetup();
        keypressed.addListener((((observableValue, aBoolean, t1) -> {
            if(!aBoolean){
                timer.start();
            }else {
                timer.stop();
            }
        })));
    }
    public void movementSetup(){
        page.setOnKeyPressed(e ->{
            if(e.getCode() == KeyCode.W){
                wpressed.set(true);
            }
            if(e.getCode() == KeyCode.A){
                apressed.set(true);
            }
            if(e.getCode() == KeyCode.S){
                spressed.set(true);
            }
            if(e.getCode() == KeyCode.D){
                dpressed.set(true);
            }

        });
        page.setOnKeyReleased(e ->{
            if(e.getCode() == KeyCode.W){
                wpressed.set(false);
            }
            if(e.getCode() == KeyCode.A){
                apressed.set(false);
            }
            if(e.getCode() == KeyCode.S){
                spressed.set(false);
            }
            if(e.getCode() == KeyCode.D){
                dpressed.set(false);
            }

        });





    }



}*/
    }
}
